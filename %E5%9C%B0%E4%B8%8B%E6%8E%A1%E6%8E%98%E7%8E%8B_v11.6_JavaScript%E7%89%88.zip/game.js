// 地下採掘王 v11.6 - JavaScript本体
"use strict";

const $ = id => document.getElementById(id);
const GRID_W = 10, GRID_H = 7, TOTAL = GRID_W * GRID_H, MAX_LAYER = 500;
const GEM_VALUES = [500,800,1200,1800,2700,4000,5900,8200,12000,18000,26000];
const SAVE_KEY = "undergroundMiningKing_v116";

let state = {
  money: 5000, layer: 1, tool: 1, bag: 0, capacity: 23, bagLevel: 0, bagValue: 0,
  robot: 0, autoSell: false, autoBag: false, autoTool: false, autoRobot: false,
  prestige: 0, dug: [], player: 34, robotPos: 0, robotTimer: null, robotTickBusy: false
};

function load() {
  try {
    const saved = JSON.parse(localStorage.getItem(SAVE_KEY));
    if (saved && typeof saved === "object") {
      const timer = state.robotTimer;
      state = {...state, ...saved, robotTimer: timer, robotTickBusy: false};
    }
  } catch (_) {}
  state.dug = Array.isArray(state.dug) ? state.dug : [];
  if (!Number.isFinite(state.player)) state.player = 34;
  if (!Number.isFinite(state.robotPos)) state.robotPos = 0;
}
function save() {
  const copy = {...state, robotTimer:null, robotTickBusy:false};
  localStorage.setItem(SAVE_KEY, JSON.stringify(copy));
}
function fmt(n) { return Math.floor(n).toLocaleString("ja-JP") + " G"; }
function priceBonus() { return 1 + state.prestige * 0.25; }
function toolCost() {
  const l = state.tool;
  return Math.ceil(70 * Math.pow(l + 1, 1.22) * (1 + Math.max(0,l - 1) * .018));
}
function bagCost() {
  return Math.ceil((300 + state.layer * 15) * (.012 + (state.bagLevel % 3) * .002));
}
function robotCost() {
  if (state.robot === 0) return 75000;
  return Math.ceil((75000 / 2) * Math.pow(1.01, state.robot - 1));
}
function gemChance() {
  return Math.min(.42, (.025 + state.layer * .00035) * (1 + state.prestige * .15));
}
function randomGem() {
  const depth = Math.min(GEM_VALUES.length - 1, Math.floor((state.layer - 1) / 48));
  const roll = Math.random();
  const index = Math.min(GEM_VALUES.length - 1, depth + Math.floor(Math.pow(roll, 2.1) * 4));
  return {index, value: GEM_VALUES[index]};
}
function message(text) { $("message").textContent = text; }

function createGrid() {
  const grid = $("grid");
  grid.innerHTML = "";
  for (let i=0; i<TOTAL; i++) {
    const cell = document.createElement("button");
    cell.type = "button";
    cell.className = "cell";
    cell.dataset.index = i;
    cell.setAttribute("aria-label", `マス ${i+1}`);
    cell.addEventListener("click", () => playerMine(i));
    grid.appendChild(cell);
  }
  renderGrid();
}
function renderGrid() {
  const cells = $("grid").children;
  for (let i=0; i<TOTAL; i++) {
    const c = cells[i];
    const dug = state.dug.includes(i);
    const gem = state.gemCells && state.gemCells.includes(i);
    c.className = "cell" + (dug ? " dug" : "") + (gem && !dug ? " gem" : "") +
      (state.player === i && !dug ? " player" : "") +
      (state.robot > 0 && state.robotPos === i && !dug ? " robot" : "");
    c.textContent = dug ? "" : (gem ? "💎" : "▪");
  }
  const count = state.dug.length;
  $("progressText").textContent = `${count} / ${TOTAL}`;
  $("progressBar").style.width = `${count / TOTAL * 100}%`;
  $("nextLayerBtn").disabled = count < TOTAL;
  $("prestigeBtn").disabled = state.layer < MAX_LAYER || count < TOTAL;
}
function updateUI() {
  $("money").textContent = fmt(state.money);
  $("layer").textContent = `${state.layer} / ${MAX_LAYER}`;
  $("tool").textContent = state.tool;
  $("robot").textContent = state.robot ? `Lv.${state.robot}` : "未所持";
  $("bag").textContent = `${state.bag} / ${state.capacity}`;
  $("toolPrice").textContent = state.tool >= 500 ? "最大レベル" : fmt(toolCost());
  $("bagPrice").textContent = fmt(bagCost());
  $("robotPrice").textContent = state.robot >= 500 ? "最大レベル" : fmt(robotCost());
  $("autoSellBuy").textContent = state.autoSell ? "購入済み" : "購入";
  $("autoSellBuy").disabled = state.autoSell;
  $("autoBag").checked = state.autoBag;
  $("autoTool").checked = state.autoTool;
  $("autoRobot").checked = state.autoRobot;
  $("prestigeInfo").textContent = `現在の転生回数：${state.prestige}回（売却×${priceBonus().toFixed(2)} / 宝石率×${(1+state.prestige*.15).toFixed(2)} / ロボ速度×${(1+state.prestige*.1).toFixed(2)}）`;
  renderGrid();
}
function addMoney(amount) {
  state.money += Math.floor(amount);
  autoUpgrade();
}
function mineReward(index) {
  const base = Math.floor((420 + 300 * state.layer) * priceBonus());
  let reward = base;
  let gemText = "";
  if (state.gemCells && state.gemCells.includes(index)) {
    const gem = randomGem();
    reward += gem.value;
    gemText = ` + 宝石${gem.index+1}（${fmt(gem.value)}）`;
  }
  return {reward, gemText};
}
function markDug(index, fromRobot=false) {
  if (state.dug.includes(index)) return false;
  state.dug.push(index);
  const {reward, gemText} = mineReward(index);
  if (fromRobot) {
    addMoney(reward);
  } else {
    state.bag += 1;
    state.bagValue += reward;
    if (state.autoSell && state.bag >= state.capacity) sellBag(true);
  }
  if (gemText) message(`採掘成功！${fmt(reward)}${gemText}`);
  return true;
}
function playerMine(index) {
  if (state.dug.includes(index)) return;
  // クリックしたマスへ移動して採掘
  state.player = index;
  markDug(index, false);
  if (state.dug.length === TOTAL) message("この階層を掘り終えた！次の階層へ進もう。");
  updateUI(); save();
}
function sellBag(auto=false) {
  if (state.bag <= 0) { if(!auto) message("バッグは空です。"); return; }
  const total = Math.floor(state.bagValue * 1.10);
  state.bag = 0; state.bagValue = 0;
  addMoney(total);
  message(`${auto ? "自動売却" : "売却"}完了！ ${fmt(total)}を獲得`);
  updateUI(); save();
}
function nextLayer() {
  if (state.dug.length < TOTAL) return;
  if (state.layer >= MAX_LAYER) { message("最深部に到達！転生できます。"); return; }
  state.layer++;
  state.dug = [];
  state.gemCells = generateGemCells();
  state.player = 34;
  state.robotPos = 0;
  message(`${state.layer}階層に到達！`);
  updateUI(); save();
}
function generateGemCells() {
  const arr = [];
  const count = Math.max(1, Math.min(8, Math.floor(1 + state.layer * .012)));
  while(arr.length < count) {
    const n = Math.floor(Math.random()*TOTAL);
    if(!arr.includes(n)) arr.push(n);
  }
  return arr;
}
function buyTool() {
  if (state.tool >= 500) return;
  const cost = toolCost();
  if (state.money < cost) { message("お金が足りません。"); return; }
  state.money -= cost; state.tool++;
  message(`ツルハシを Lv.${state.tool} に強化！`);
  updateUI(); save();
}
function buyBag() {
  const cost = bagCost();
  if (state.money < cost) { message("バッグ拡張のお金が足りません。"); return; }
  state.money -= cost; state.capacity += 15; state.bagLevel++;
  updateUI(); save();
}
function buyRobot() {
  if (state.robot >= 500) return;
  const cost = robotCost();
  if (state.money < cost) { message("ロボット強化のお金が足りません。"); return; }
  state.money -= cost; state.robot++;
  message(state.robot === 1 ? "ロボットを購入した！" : `ロボットを Lv.${state.robot} に強化！`);
  startRobot(); updateUI(); save();
}
function buyAutoSell() {
  if(state.autoSell) return;
  if(state.money < 100000) { message("自動売却には100,000 G必要です。"); return; }
  state.money -= 100000; state.autoSell = true;
  message("自動売却を購入！バッグが満杯になると自動で売却します。");
  updateUI(); save();
}
function autoUpgrade() {
  // 購入可能なものを順に購入。無限ループ防止のため各項目に上限。
  if(state.autoBag) {
    let guard=0;
    while(guard++<100 && state.money >= bagCost()) { state.money -= bagCost(); state.capacity += 15; state.bagLevel++; }
  }
  if(state.autoTool) {
    let guard=0;
    while(guard++<100 && state.tool<500 && state.money >= toolCost()) { state.money -= toolCost(); state.tool++; }
  }
  if(state.autoRobot) {
    let guard=0;
    while(guard++<100 && state.robot<500 && state.money >= robotCost()) { state.money -= robotCost(); state.robot++; }
    if(state.robot>0) startRobot();
  }
}
function robotIntervalMs() {
  return Math.max(5000, (5 - Math.floor(state.robot/10)*.1) * 1000 / (1 + state.prestige*.1));
}
function startRobot() {
  if(state.robot <= 0 || state.robotTimer) return;
  state.robotTimer = setInterval(robotMineTick, robotIntervalMs());
}
function robotMineTick() {
  if(state.robot <= 0 || state.robotTickBusy) return;
  state.robotTickBusy = true;
  try {
    if(state.dug.length >= TOTAL) return;
    if(state.robot >= 500) {
      for(let i=0;i<TOTAL;i++) if(!state.dug.includes(i)) markDug(i,true);
      message("ロボット Lv.500！この階層を一気に採掘した！");
    } else {
      let index = state.robotPos % TOTAL;
      let tries=0;
      while(state.dug.includes(index) && tries++<TOTAL) index=(index+1)%TOTAL;
      state.robotPos=index;
      markDug(index,true);
      state.robotPos=(index+1)%TOTAL;
    }
    updateUI(); save();
  } finally {
    state.robotTickBusy = false;
  }
}
function prestige() {
  if(state.layer<MAX_LAYER || state.dug.length<TOTAL) return;
  if(!confirm("転生しますか？所持金・バッグ・強化・階層がリセットされます。永続ボーナスを獲得します。")) return;
  const keepAutoSell = state.autoSell;
  const keepAutoBag = state.autoBag, keepAutoTool = state.autoTool, keepAutoRobot = state.autoRobot;
  state.money = 5000 + state.prestige * 10000;
  state.layer = 1; state.tool = 1; state.bag = 0; state.capacity = 23;
  state.bagLevel = 0; state.bagValue = 0; state.robot = 0;
  state.prestige++; state.dug=[]; state.gemCells=generateGemCells();
  state.player=34; state.robotPos=0;
  state.autoSell=keepAutoSell; state.autoBag=keepAutoBag;
  state.autoTool=keepAutoTool; state.autoRobot=keepAutoRobot;
  if(state.robotTimer){clearInterval(state.robotTimer);state.robotTimer=null;}
  message("転生完了！永続ボーナスが強化された！");
  updateUI(); save();
}
function bindEvents() {
  $("sellBtn").addEventListener("click",()=>sellBag(false));
  $("nextLayerBtn").addEventListener("click",nextLayer);
  $("toolBuy").addEventListener("click",buyTool);
  $("bagBuy").addEventListener("click",buyBag);
  $("robotBuy").addEventListener("click",buyRobot);
  $("autoSellBuy").addEventListener("click",buyAutoSell);
  $("prestigeBtn").addEventListener("click",prestige);
  $("autoBag").addEventListener("change",e=>{state.autoBag=e.target.checked;autoUpgrade();updateUI();save();});
  $("autoTool").addEventListener("change",e=>{state.autoTool=e.target.checked;autoUpgrade();updateUI();save();});
  $("autoRobot").addEventListener("change",e=>{state.autoRobot=e.target.checked;autoUpgrade();updateUI();save();});
}
function init() {
  load();
  if(!Array.isArray(state.gemCells) || !state.gemCells.length) state.gemCells=generateGemCells();
  bindEvents(); createGrid(); autoUpgrade(); updateUI(); startRobot(); save();
}
init();
